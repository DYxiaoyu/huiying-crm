"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FollowUpsService", {
    enumerable: true,
    get: function() {
        return FollowUpsService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _drizzleorm = require("drizzle-orm");
const _schema = require("../../database/schema");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let FollowUpsService = class FollowUpsService {
    async listByCustomer(customerId, employeeId) {
        // verify customer exists and belongs to employee
        const customerRows = await this.db.select({
            id: _schema.customers.id,
            name: _schema.customers.name
        }).from(_schema.customers).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, customerId), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId))).limit(1);
        if (customerRows.length === 0) {
            throw new _common.NotFoundException('客户不存在');
        }
        const customerName = customerRows[0].name;
        const rows = await this.db.select().from(_schema.followUps).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.followUps.customerId, customerId), (0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId))).orderBy((0, _drizzleorm.desc)(_schema.followUps.followAt)).limit(100);
        return rows.map((row)=>this.toFollowUpDto(row, customerName));
    }
    async create(dto, employeeId) {
        const { customerId, content, result, followAt } = dto;
        const customerList = await this.db.select({
            id: _schema.customers.id,
            name: _schema.customers.name
        }).from(_schema.customers).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, customerId), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId)));
        if (customerList.length === 0) {
            throw new _common.NotFoundException('客户不存在');
        }
        const customerName = customerList[0].name;
        const createdList = await this.db.transaction(async (tx)=>{
            const inserted = await tx.insert(_schema.followUps).values({
                customerId,
                content,
                result: result ?? null,
                followAt: followAt ? new Date(followAt) : new Date(),
                employeeId
            }).returning();
            await tx.update(_schema.customers).set({
                updatedAt: new Date()
            }).where((0, _drizzleorm.eq)(_schema.customers.id, customerId));
            return inserted;
        });
        this.logger.log(`新增跟进记录成功 customerId=${customerId}`);
        return this.toFollowUpDto(createdList[0], customerName);
    }
    toFollowUpDto(row, customerName) {
        return {
            id: row.id,
            customerId: row.customerId,
            customerName,
            content: row.content,
            result: row.result,
            followAt: row.followAt.toISOString(),
            employeeId: row.employeeId ?? '',
            createdAt: row.createdAt.toISOString()
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(FollowUpsService.name);
    }
};
FollowUpsService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], FollowUpsService);
