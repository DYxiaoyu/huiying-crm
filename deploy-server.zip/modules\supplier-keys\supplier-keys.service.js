"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SupplierKeysService", {
    enumerable: true,
    get: function() {
        return SupplierKeysService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _schema = require("../../database/schema");
const _drizzleorm = require("drizzle-orm");
const _crypto = require("crypto");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function generateKey() {
    const a = (0, _crypto.randomBytes)(4).toString('hex').toUpperCase();
    const b = (0, _crypto.randomBytes)(4).toString('hex').toUpperCase();
    return `HYJJ-${a}-${b}`;
}
let SupplierKeysService = class SupplierKeysService {
    async list() {
        const rows = await this.db.select().from(_schema.supplierKeys).orderBy(_schema.supplierKeys.createdAt);
        return rows.map((row)=>this.toKey(row));
    }
    async create(dto) {
        if (!dto.label || !dto.label.trim()) {
            throw new _common.BadRequestException('请填写密钥备注（如供应商公司名）');
        }
        let key = generateKey();
        // 防碰撞：极小概率，重试一次
        const exists = await this.db.select({
            id: _schema.supplierKeys.id
        }).from(_schema.supplierKeys).where((0, _drizzleorm.eq)(_schema.supplierKeys.key, key)).limit(1);
        if (exists.length > 0) {
            key = generateKey();
        }
        const inserted = await this.db.insert(_schema.supplierKeys).values({
            key,
            label: dto.label.trim()
        }).returning();
        this.logger.log(`生成供应商密钥: ${inserted[0].key} (${inserted[0].label})`);
        return this.toKey(inserted[0]);
    }
    async update(id, patch) {
        const existing = await this.db.select().from(_schema.supplierKeys).where((0, _drizzleorm.eq)(_schema.supplierKeys.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('密钥不存在');
        }
        const values = {};
        if (patch.label !== undefined) values.label = patch.label.trim() || existing[0].label;
        if (patch.enabled !== undefined) values.enabled = patch.enabled;
        values.updatedAt = new Date();
        const updated = await this.db.update(_schema.supplierKeys).set(values).where((0, _drizzleorm.eq)(_schema.supplierKeys.id, id)).returning();
        return this.toKey(updated[0]);
    }
    async remove(id) {
        const existing = await this.db.select().from(_schema.supplierKeys).where((0, _drizzleorm.eq)(_schema.supplierKeys.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('密钥不存在');
        }
        await this.db.delete(_schema.supplierKeys).where((0, _drizzleorm.eq)(_schema.supplierKeys.id, id));
        this.logger.log(`删除供应商密钥: ${id}`);
    }
    toKey(row) {
        return {
            id: row.id,
            key: row.key,
            label: row.label,
            enabled: row.enabled,
            createdAt: row.createdAt.toISOString(),
            updatedAt: row.updatedAt.toISOString()
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(SupplierKeysService.name);
    }
};
SupplierKeysService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], SupplierKeysService);
