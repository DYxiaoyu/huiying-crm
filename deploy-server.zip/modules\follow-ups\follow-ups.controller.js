"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FollowUpsController", {
    enumerable: true,
    get: function() {
        return FollowUpsController;
    }
});
const _common = require("@nestjs/common");
const _followupsservice = require("./follow-ups.service");
const _employeeauthguard = require("../auth/employee-auth.guard");
const _currentemployeedecorator = require("../auth/current-employee.decorator");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let FollowUpsController = class FollowUpsController {
    async listByCustomer(employee, customerId) {
        return this.followUpsService.listByCustomer(customerId, employee.id);
    }
    async create(employee, dto) {
        return this.followUpsService.create(dto, employee.id);
    }
    constructor(followUpsService){
        this.followUpsService = followUpsService;
    }
};
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Query)('customerId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], FollowUpsController.prototype, "listByCustomer", null);
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        typeof CreateFollowUpDto === "undefined" ? Object : CreateFollowUpDto
    ]),
    _ts_metadata("design:returntype", Promise)
], FollowUpsController.prototype, "create", null);
FollowUpsController = _ts_decorate([
    (0, _common.Controller)('api/follow-ups'),
    (0, _common.UseGuards)(_employeeauthguard.EmployeeAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _followupsservice.FollowUpsService === "undefined" ? Object : _followupsservice.FollowUpsService
    ])
], FollowUpsController);
