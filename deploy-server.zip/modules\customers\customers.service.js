"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CustomersService", {
    enumerable: true,
    get: function() {
        return CustomersService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _schema = require("../../database/schema");
const _drizzleorm = require("drizzle-orm");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
let CustomersService = class CustomersService {
    async list(params, employeeId) {
        const { page, pageSize: rawPageSize, keyword, stage, sortBy, sortOrder, favoriteOnly } = params;
        const safePage = Math.max(1, page);
        const safePageSize = Math.min(50, Math.max(1, rawPageSize));
        const offset = (safePage - 1) * safePageSize;
        const conditions = [
            (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId)
        ];
        if (keyword && keyword.trim()) {
            const pattern = `%${keyword.trim()}%`;
            conditions.push((0, _drizzleorm.or)((0, _drizzleorm.ilike)(_schema.customers.name, pattern), (0, _drizzleorm.ilike)(_schema.customers.phone, pattern), (0, _drizzleorm.ilike)(_schema.customers.company, pattern)));
        }
        if (stage) {
            conditions.push((0, _drizzleorm.eq)(_schema.customers.stage, stage));
        }
        if (favoriteOnly) {
            conditions.push((0, _drizzleorm.eq)(_schema.customers.isFavorite, true));
        }
        const whereClause = (0, _drizzleorm.and)(...conditions);
        const orderCol = sortBy === 'createdAt' ? _schema.customers.createdAt : sortBy === 'name' ? _schema.customers.name : _schema.customers.updatedAt;
        const orderFn = sortOrder === 'asc' ? _drizzleorm.asc : _drizzleorm.desc;
        const [countResult, rows] = await Promise.all([
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.customers).where(whereClause),
            this.db.select().from(_schema.customers).where(whereClause).orderBy(orderFn(orderCol)).limit(safePageSize).offset(offset)
        ]);
        const total = Number(countResult[0]?.count ?? 0);
        const customerIds = rows.map((row)=>row.id);
        let lastFollowMap = new Map();
        if (customerIds.length > 0) {
            const lastFollowRows = await this.db.select({
                customerId: _schema.followUps.customerId,
                lastFollowAt: (0, _drizzleorm.max)(_schema.followUps.followAt)
            }).from(_schema.followUps).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId), (0, _drizzleorm.inArray)(_schema.followUps.customerId, customerIds))).groupBy(_schema.followUps.customerId);
            for (const r of lastFollowRows){
                if (r.lastFollowAt) {
                    lastFollowMap.set(r.customerId, r.lastFollowAt);
                }
            }
        }
        const now = Date.now();
        const items = rows.map((row)=>{
            const lastFollow = lastFollowMap.get(row.id) ?? null;
            const baseline = lastFollow ?? row.createdAt;
            const isOverdue = now - baseline.getTime() > SEVEN_DAYS_MS;
            return this.toCustomer(row, lastFollow, isOverdue);
        });
        return {
            items,
            total,
            page: safePage,
            pageSize: safePageSize
        };
    }
    async detail(id, employeeId) {
        const rows = await this.db.select().from(_schema.customers).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, id), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId))).limit(1);
        if (rows.length === 0) {
            throw new _common.NotFoundException('客户不存在');
        }
        const lastFollowRows = await this.db.select({
            lastFollowAt: (0, _drizzleorm.max)(_schema.followUps.followAt)
        }).from(_schema.followUps).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.followUps.customerId, id), (0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId)));
        const lastFollow = lastFollowRows[0]?.lastFollowAt ?? null;
        const now = Date.now();
        const baseline = lastFollow ?? rows[0].createdAt;
        const isOverdue = now - baseline.getTime() > SEVEN_DAYS_MS;
        return this.toCustomer(rows[0], lastFollow, isOverdue);
    }
    async create(dto, employeeId) {
        if (!dto.name || !dto.name.trim()) {
            throw new _common.BadRequestException('客户姓名不能为空');
        }
        const inserted = await this.db.insert(_schema.customers).values({
            name: dto.name.trim(),
            phone: dto.phone ?? null,
            company: dto.company ?? null,
            source: dto.source ?? null,
            stage: dto.stage ?? 'new',
            remark: dto.remark ?? null,
            employeeId
        }).returning();
        this.logger.log(`创建客户成功: ${inserted[0].id}`);
        return this.toCustomer(inserted[0], null, false);
    }
    async update(id, dto, employeeId) {
        const existing = await this.db.select().from(_schema.customers).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, id), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId))).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('客户不存在');
        }
        const patch = {};
        if (dto.name !== undefined) patch.name = dto.name.trim();
        if (dto.phone !== undefined) patch.phone = dto.phone;
        if (dto.company !== undefined) patch.company = dto.company;
        if (dto.source !== undefined) patch.source = dto.source;
        if (dto.stage !== undefined) patch.stage = dto.stage;
        if (dto.remark !== undefined) patch.remark = dto.remark;
        if (dto.isFavorite !== undefined) patch.isFavorite = dto.isFavorite;
        if (Object.keys(patch).length === 0) {
            throw new _common.BadRequestException('未提供可更新字段');
        }
        patch.updatedAt = new Date();
        const updated = await this.db.update(_schema.customers).set(patch).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, id), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId))).returning();
        this.logger.log(`更新客户成功: ${id}`);
        const lastFollowRows = await this.db.select({
            lastFollowAt: (0, _drizzleorm.max)(_schema.followUps.followAt)
        }).from(_schema.followUps).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.followUps.customerId, id), (0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId)));
        const lastFollow = lastFollowRows[0]?.lastFollowAt ?? null;
        const now = Date.now();
        const baseline = lastFollow ?? updated[0].createdAt;
        const isOverdue = now - baseline.getTime() > SEVEN_DAYS_MS;
        return this.toCustomer(updated[0], lastFollow, isOverdue);
    }
    async remove(id, employeeId) {
        const existing = await this.db.select().from(_schema.customers).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.customers.id, id), (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId))).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('客户不存在');
        }
        await this.db.delete(_schema.customers).where((0, _drizzleorm.eq)(_schema.customers.id, id));
        this.logger.log(`删除客户成功: ${id}`);
    }
    async checkDuplicate(name, phone, excludeId, employeeId) {
        const conditions = [
            (0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId)
        ];
        const nameConditions = [
            ...conditions
        ];
        const phoneConditions = [
            ...conditions
        ];
        if (excludeId) {
            nameConditions.push((0, _drizzleorm.ne)(_schema.customers.id, excludeId));
            phoneConditions.push((0, _drizzleorm.ne)(_schema.customers.id, excludeId));
        }
        let duplicateName;
        let duplicatePhone;
        const queries = [];
        if (name && name.trim()) {
            queries.push(this.db.select({
                name: _schema.customers.name
            }).from(_schema.customers).where((0, _drizzleorm.and)(...nameConditions, (0, _drizzleorm.eq)(_schema.customers.name, name.trim()))).limit(1).then((rows)=>{
                if (rows.length > 0) duplicateName = rows[0].name;
            }));
        }
        if (phone && phone.trim()) {
            queries.push(this.db.select({
                phone: _schema.customers.phone
            }).from(_schema.customers).where((0, _drizzleorm.and)(...phoneConditions, (0, _drizzleorm.eq)(_schema.customers.phone, phone.trim()))).limit(1).then((rows)=>{
                if (rows.length > 0 && rows[0].phone) duplicatePhone = rows[0].phone;
            }));
        }
        await Promise.all(queries);
        return {
            hasDuplicate: !!(duplicateName || duplicatePhone),
            duplicateName,
            duplicatePhone
        };
    }
    async importCustomers(items, employeeId) {
        if (!Array.isArray(items) || items.length === 0) {
            throw new _common.BadRequestException('没有可导入的数据');
        }
        const errors = [];
        let imported = 0;
        const validRows = [];
        const stageSet = new Set([
            'new',
            'contacted',
            'following',
            'closed',
            'lost'
        ]);
        items.forEach((item, index)=>{
            const name = item.name?.trim();
            if (!name) {
                errors.push(`第 ${index + 1} 行缺少客户姓名`);
                return;
            }
            const stage = item.stage && stageSet.has(item.stage) ? item.stage : 'new';
            validRows.push({
                name,
                phone: item.phone?.trim() || null,
                company: item.company?.trim() || null,
                source: item.source?.trim() || null,
                stage,
                remark: item.remark?.trim() || null,
                employeeId
            });
        });
        if (validRows.length > 0) {
            // 分批插入（每批 200 条）
            for(let i = 0; i < validRows.length; i += 200){
                const batch = validRows.slice(i, i + 200);
                await this.db.insert(_schema.customers).values(batch);
            }
            imported = validRows.length;
        }
        this.logger.log(`导入客户成功: ${imported} 条, 跳过 ${items.length - imported} 条`);
        return {
            imported,
            skipped: items.length - imported,
            errors
        };
    }
    async exportCsv(employeeId) {
        const allCustomers = await this.db.select().from(_schema.customers).where((0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId)).orderBy((0, _drizzleorm.desc)(_schema.customers.updatedAt));
        const customerIds = allCustomers.map((row)=>row.id);
        // get last follow-up per customer
        const lastFollowMap = new Map();
        if (customerIds.length > 0) {
            // Use a window function approach: query all follow-ups grouped by customer, take max followAt
            // Since no raw SQL, do aggregate + then fetch content in a second query per customer
            // Better: fetch all follow-ups for these customers, compute max in memory
            const allFollowUps = await this.db.select({
                customerId: _schema.followUps.customerId,
                followAt: _schema.followUps.followAt,
                content: _schema.followUps.content
            }).from(_schema.followUps).where((0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId));
            for (const fu of allFollowUps){
                const existing = lastFollowMap.get(fu.customerId);
                if (!existing || fu.followAt.getTime() > existing.followAt.getTime()) {
                    lastFollowMap.set(fu.customerId, {
                        followAt: fu.followAt,
                        content: fu.content
                    });
                }
            }
        }
        const headers = [
            '客户姓名',
            '电话',
            '公司',
            '来源',
            '阶段',
            '备注',
            '最近跟进时间',
            '最近跟进内容',
            '创建时间',
            '更新时间'
        ];
        const stageNameMap = {
            new: '新客户',
            contacted: '已联系',
            following: '跟进中',
            closed: '已成交',
            lost: '已流失'
        };
        const escapeCsv = (value)=>{
            if (value == null) return '';
            const s = String(value);
            if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r')) {
                return `"${s.replace(/"/g, '""')}"`;
            }
            return s;
        };
        const lines = [
            headers.join(',')
        ];
        for (const c of allCustomers){
            const lastFollow = lastFollowMap.get(c.id);
            const row = [
                escapeCsv(c.name),
                escapeCsv(c.phone),
                escapeCsv(c.company),
                escapeCsv(c.source),
                escapeCsv(stageNameMap[c.stage] ?? c.stage),
                escapeCsv(c.remark),
                escapeCsv(lastFollow ? lastFollow.followAt.toISOString() : ''),
                escapeCsv(lastFollow ? lastFollow.content : ''),
                escapeCsv(c.createdAt.toISOString()),
                escapeCsv(c.updatedAt.toISOString())
            ];
            lines.push(row.join(','));
        }
        return '\uFEFF' + lines.join('\r\n');
    }
    async exportBackup(employeeId) {
        const allCustomers = await this.db.select().from(_schema.customers).where((0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId)).orderBy((0, _drizzleorm.desc)(_schema.customers.createdAt));
        const allFollowUps = await this.db.select().from(_schema.followUps).where((0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId)).orderBy((0, _drizzleorm.desc)(_schema.followUps.followAt));
        const customerIds = allCustomers.map((row)=>row.id);
        const lastFollowMap = new Map();
        for (const fu of allFollowUps){
            const existing = lastFollowMap.get(fu.customerId);
            if (!existing || fu.followAt.getTime() > existing.getTime()) {
                lastFollowMap.set(fu.customerId, fu.followAt);
            }
        }
        const now = Date.now();
        const exportedCustomers = allCustomers.map((row)=>{
            const lastFollow = lastFollowMap.get(row.id) ?? null;
            const baseline = lastFollow ?? row.createdAt;
            const isOverdue = now - baseline.getTime() > SEVEN_DAYS_MS;
            return this.toCustomer(row, lastFollow, isOverdue);
        });
        const exportedFollowUps = allFollowUps.map((row)=>({
                id: row.id,
                customerId: row.customerId,
                content: row.content,
                result: row.result,
                followAt: row.followAt.toISOString(),
                employeeId: row.employeeId ?? '',
                createdAt: row.createdAt.toISOString()
            }));
        return {
            customers: exportedCustomers,
            followUps: exportedFollowUps,
            exportedAt: new Date().toISOString()
        };
    }
    toCustomer(row, lastFollowAt, isOverdue) {
        return {
            id: row.id,
            name: row.name,
            phone: row.phone,
            company: row.company,
            source: row.source,
            stage: row.stage,
            remark: row.remark,
            employeeId: row.employeeId ?? '',
            createdAt: row.createdAt.toISOString(),
            updatedAt: row.updatedAt.toISOString(),
            lastFollowAt: lastFollowAt ? lastFollowAt.toISOString() : null,
            isOverdue,
            isFavorite: row.isFavorite ?? false
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(CustomersService.name);
    }
};
CustomersService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], CustomersService);
