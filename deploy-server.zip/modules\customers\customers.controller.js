"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CustomersController", {
    enumerable: true,
    get: function() {
        return CustomersController;
    }
});
const _common = require("@nestjs/common");
const _customersservice = require("./customers.service");
const _employeeauthguard = require("../auth/employee-auth.guard");
const _currentemployeedecorator = require("../auth/current-employee.decorator");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let CustomersController = class CustomersController {
    async list(employee, page, pageSize, keyword, stage, sortBy, sortOrder, favoriteOnly) {
        const pageNum = page ? parseInt(page, 10) : 1;
        const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
        const stageFilter = stage && stage !== '' ? stage : undefined;
        const safeSortBy = sortBy === 'createdAt' || sortBy === 'name' ? sortBy : 'updatedAt';
        const safeSortOrder = sortOrder === 'asc' ? 'asc' : 'desc';
        return this.customersService.list({
            page: pageNum,
            pageSize: pageSizeNum,
            keyword,
            stage: stageFilter,
            sortBy: safeSortBy,
            sortOrder: safeSortOrder,
            favoriteOnly: favoriteOnly === 'true'
        }, employee.id);
    }
    async checkDuplicate(employee, name, phone, excludeId) {
        return this.customersService.checkDuplicate(name, phone, excludeId, employee.id);
    }
    async exportCsv(employee, res) {
        const csv = await this.customersService.exportCsv(employee.id);
        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="customers.csv"');
        res.send(csv);
    }
    async exportBackup(employee, res) {
        const data = await this.customersService.exportBackup(employee.id);
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="customers-backup.json"');
        res.json(data);
    }
    async importCustomers(employee, body) {
        return this.customersService.importCustomers(body?.items ?? [], employee.id);
    }
    async detail(employee, id) {
        return this.customersService.detail(id, employee.id);
    }
    async create(employee, dto) {
        return this.customersService.create(dto, employee.id);
    }
    async update(employee, id, dto) {
        return this.customersService.update(id, dto, employee.id);
    }
    async remove(employee, id) {
        return this.customersService.remove(id, employee.id);
    }
    constructor(customersService){
        this.customersService = customersService;
    }
};
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Query)('page')),
    _ts_param(2, (0, _common.Query)('pageSize')),
    _ts_param(3, (0, _common.Query)('keyword')),
    _ts_param(4, (0, _common.Query)('stage')),
    _ts_param(5, (0, _common.Query)('sortBy')),
    _ts_param(6, (0, _common.Query)('sortOrder')),
    _ts_param(7, (0, _common.Query)('favoriteOnly')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        String,
        String,
        String,
        String,
        String,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "list", null);
_ts_decorate([
    (0, _common.Get)('check-duplicate'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Query)('name')),
    _ts_param(2, (0, _common.Query)('phone')),
    _ts_param(3, (0, _common.Query)('excludeId')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        String,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "checkDuplicate", null);
_ts_decorate([
    (0, _common.Get)('export/csv'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Res)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        typeof Response === "undefined" ? Object : Response
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "exportCsv", null);
_ts_decorate([
    (0, _common.Get)('export/backup'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Res)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        typeof Response === "undefined" ? Object : Response
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "exportBackup", null);
_ts_decorate([
    (0, _common.Post)('import'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "importCustomers", null);
_ts_decorate([
    (0, _common.Get)(':id'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "detail", null);
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        typeof CreateCustomerDto === "undefined" ? Object : CreateCustomerDto
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "create", null);
_ts_decorate([
    (0, _common.Patch)(':id'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_param(2, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String,
        typeof UpdateCustomerDto === "undefined" ? Object : UpdateCustomerDto
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "update", null);
_ts_decorate([
    (0, _common.Delete)(':id'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], CustomersController.prototype, "remove", null);
CustomersController = _ts_decorate([
    (0, _common.Controller)('api/customers'),
    (0, _common.UseGuards)(_employeeauthguard.EmployeeAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _customersservice.CustomersService === "undefined" ? Object : _customersservice.CustomersService
    ])
], CustomersController);
