"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const _core = require("@nestjs/core");
const _common = require("@nestjs/common");
const _path = require("path");
const _hbs = require("hbs");
const _express = require("express");
const _cookieparser = /*#__PURE__*/ _interop_require_default(require("cookie-parser"));
const _appmodule = require("./app.module");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
async function bootstrap() {
    const app = await _core.NestFactory.create(_appmodule.AppModule, {
        abortOnError: process.env.NODE_ENV !== 'development'
    });
    const logger = new _common.Logger('Bootstrap');
    const host = process.env.SERVER_HOST || 'localhost';
    const port = Number(process.env.SERVER_PORT || '3000');
    const bodyLimit = process.env.BODY_SIZE_LIMIT || '10mb';
    // body 解析（替代原平台 configureApp）
    app.use((0, _express.json)({
        limit: bodyLimit
    }));
    app.use((0, _express.urlencoded)({
        limit: bodyLimit,
        extended: true
    }));
    app.use((0, _cookieparser.default)());
    app.set('trust proxy', true);
    // 注册视图引擎, 渲染 client 目录下的 html 文件
    // 注意：vite 产物中 HTML 位于 dist/client/client/index.html，静态资源位于 dist/client/assets
    app.setBaseViewsDir((0, _path.join)(process.cwd(), 'dist/client/client'));
    app.useStaticAssets((0, _path.join)(process.cwd(), 'dist/client'), {
        index: false
    });
    app.setViewEngine('html');
    app.engine('html', _hbs.__express);
    await app.listen(port, host);
    logger.log(`Server running on ${host}:${port}`);
    logger.log(`API endpoints ready at http://${host}:${port}/api`);
}
bootstrap();
