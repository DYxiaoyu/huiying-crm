"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "LeadController", {
    enumerable: true,
    get: function() {
        return LeadController;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _schema = require("../../database/schema");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let LeadController = class LeadController {
    async submit(dto) {
        const name = (dto.name || '').trim();
        const phone = (dto.phone || '').trim();
        if (!name) throw new _common.BadRequestException('姓名不能为空');
        if (!phone) throw new _common.BadRequestException('手机号不能为空');
        // 通用手机号校验：+ 和数字，7~20位
        if (!/^\+?[0-9\s\-]{7,20}$/.test(phone.replace(/\s/g, ''))) {
            throw new _common.BadRequestException('手机号格式不正确');
        }
        // 拼装备注（分行）
        const remarkLines = [];
        if (dto.company?.trim()) remarkLines.push(`公司：${dto.company.trim()}`);
        if (dto.whatsapp?.trim()) remarkLines.push(`WhatsApp：${dto.whatsapp.trim()}`);
        if (dto.telegram?.trim()) remarkLines.push(`Telegram：${dto.telegram.trim()}`);
        if (dto.email?.trim()) remarkLines.push(`邮箱：${dto.email.trim()}`);
        if (dto.address?.trim()) remarkLines.push(`地址：${dto.address.trim()}`);
        if (dto.product?.trim()) remarkLines.push(`意向产品：${dto.product.trim()}`);
        if (dto.budget?.trim()) remarkLines.push(`预算：${dto.budget.trim()}`);
        if (dto.requirement?.trim()) remarkLines.push(`需求描述：${dto.requirement.trim()}`);
        await this.db.insert(_schema.customers).values({
            name,
            phone,
            company: dto.company?.trim() || null,
            source: '网页客户',
            stage: 'new',
            remark: remarkLines.join('\n')
        });
        this.logger.log(`新网页客户：${name} / ${phone}`);
        return {
            ok: true
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(LeadController.name);
    }
};
_ts_decorate([
    (0, _common.Post)(),
    (0, _common.HttpCode)(200),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof LeadDto === "undefined" ? Object : LeadDto
    ]),
    _ts_metadata("design:returntype", Promise)
], LeadController.prototype, "submit", null);
LeadController = _ts_decorate([
    (0, _common.Controller)('api/lead'),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], LeadController);
