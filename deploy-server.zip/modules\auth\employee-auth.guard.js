"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "EmployeeAuthGuard", {
    enumerable: true,
    get: function() {
        return EmployeeAuthGuard;
    }
});
const _common = require("@nestjs/common");
const _jsonwebtoken = require("jsonwebtoken");
const _authservice = require("./auth.service");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
let EmployeeAuthGuard = class EmployeeAuthGuard {
    canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const authHeader = request.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new _common.UnauthorizedException('未提供有效的认证令牌');
        }
        const token = authHeader.slice(7);
        try {
            const payload = (0, _jsonwebtoken.verify)(token, _authservice.JWT_SECRET);
            const employee = {
                id: payload.employeeId,
                username: payload.username,
                name: payload.name,
                role: payload.role === 'admin' ? 'admin' : 'employee'
            };
            request.employee = employee;
            return true;
        } catch  {
            throw new _common.UnauthorizedException('认证令牌无效或已过期');
        }
    }
};
EmployeeAuthGuard = _ts_decorate([
    (0, _common.Injectable)()
], EmployeeAuthGuard);
