"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AppModule", {
    enumerable: true,
    get: function() {
        return AppModule;
    }
});
const _core = require("@nestjs/core");
const _common = require("@nestjs/common");
const _exceptionfilter = require("./common/filters/exception.filter");
const _databasemodule = require("./database/database.module");
const _viewmodule = require("./modules/view/view.module");
const _authmodule = require("./modules/auth/auth.module");
const _customersmodule = require("./modules/customers/customers.module");
const _suppliersmodule = require("./modules/suppliers/suppliers.module");
const _supplierpublicmodule = require("./modules/supplier-public/supplier-public.module");
const _supplierkeysmodule = require("./modules/supplier-keys/supplier-keys.module");
const _adminmodule = require("./modules/admin/admin.module");
const _dashboardmodule = require("./modules/dashboard/dashboard.module");
const _followupsmodule = require("./modules/follow-ups/follow-ups.module");
const _leadmodule = require("./modules/lead/lead.module");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
let AppModule = class AppModule {
};
AppModule = _ts_decorate([
    (0, _common.Module)({
        imports: [
            // 独立部署版：使用标准 PostgreSQL + Drizzle，不依赖任何平台能力
            _databasemodule.DatabaseModule,
            // ====== @route-section: business-modules START ======
            // Place all business modules here.Do NOT add fallback modules here.
            _authmodule.AuthModule,
            _customersmodule.CustomersModule,
            _suppliersmodule.SuppliersModule,
            _supplierpublicmodule.SupplierPublicModule,
            _supplierkeysmodule.SupplierKeysModule,
            _adminmodule.AdminModule,
            _dashboardmodule.DashboardModule,
            _followupsmodule.FollowUpsModule,
            _leadmodule.LeadModule,
            // ====== @route-section: business-modules END ======
            // ⚠️ @route-order: last
            // ViewModule is the fallback route module, must be registered last.
            _viewmodule.ViewModule
        ],
        providers: [
            {
                provide: _core.APP_FILTER,
                useClass: _exceptionfilter.GlobalExceptionFilter
            }
        ]
    })
], AppModule);
