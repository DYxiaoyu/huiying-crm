"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AuthService () {
        return AuthService;
    },
    get JWT_SECRET () {
        return JWT_SECRET;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _drizzleorm = require("drizzle-orm");
const _bcryptjs = require("bcryptjs");
const _jsonwebtoken = require("jsonwebtoken");
const _schema = require("../../database/schema");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
const JWT_SECRET = 'crm-jwt-secret-key-2026';
const JWT_EXPIRES_IN = '7d';
const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,20}$/;
let AuthService = class AuthService {
    async register(dto) {
        const { name, username, password } = dto;
        if (!USERNAME_REGEX.test(username)) {
            throw new _common.BadRequestException('用户名需为3-20位字母、数字或下划线');
        }
        if (!password || password.length < 4) {
            throw new _common.BadRequestException('密码至少4位');
        }
        if (!name || name.trim().length === 0) {
            throw new _common.BadRequestException('姓名不能为空');
        }
        const existing = await this.db.select({
            id: _schema.employees.id
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.username, username));
        if (existing.length > 0) {
            throw new _common.ConflictException('用户名已存在');
        }
        const passwordHash = (0, _bcryptjs.hashSync)(password, 10);
        const inserted = await this.db.insert(_schema.employees).values({
            name,
            username,
            passwordHash,
            role: dto.role ?? 'employee'
        }).returning({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            role: _schema.employees.role
        });
        const employee = {
            id: inserted[0].id,
            name: inserted[0].name,
            username: inserted[0].username,
            role: inserted[0].role ?? 'employee'
        };
        const token = this.generateToken(employee);
        this.logger.log(`员工注册成功: ${username}`);
        return {
            token,
            employee
        };
    }
    async login(dto) {
        const { username, password } = dto;
        const found = await this.db.select({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            passwordHash: _schema.employees.passwordHash,
            role: _schema.employees.role
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.username, username));
        if (found.length === 0) {
            throw new _common.UnauthorizedException('用户名或密码错误');
        }
        const row = found[0];
        const valid = (0, _bcryptjs.compareSync)(password, row.passwordHash);
        if (!valid) {
            throw new _common.UnauthorizedException('用户名或密码错误');
        }
        const employee = {
            id: row.id,
            name: row.name,
            username: row.username,
            role: row.role ?? 'employee'
        };
        const token = this.generateToken(employee);
        this.logger.log(`员工登录成功: ${username}`);
        return {
            token,
            employee
        };
    }
    generateToken(employee) {
        return (0, _jsonwebtoken.sign)({
            employeeId: employee.id,
            username: employee.username,
            name: employee.name,
            role: employee.role
        }, JWT_SECRET, {
            expiresIn: JWT_EXPIRES_IN
        });
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(AuthService.name);
    }
};
AuthService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], AuthService);
