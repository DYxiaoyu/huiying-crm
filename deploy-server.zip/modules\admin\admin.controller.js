"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AdminController", {
    enumerable: true,
    get: function() {
        return AdminController;
    }
});
const _common = require("@nestjs/common");
const _adminservice = require("./admin.service");
const _employeeauthguard = require("../auth/employee-auth.guard");
const _adminguard = require("../auth/admin.guard");
const _currentemployeedecorator = require("../auth/current-employee.decorator");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let AdminController = class AdminController {
    /** 老板后台：全局总览 + 员工列表 */ async getOverview() {
        return this.adminService.getOverview();
    }
    /** 员工列表 */ async getEmployees() {
        return this.adminService.getEmployeeList();
    }
    /** 创建员工账号 */ async createEmployee(dto) {
        return this.adminService.createEmployee(dto);
    }
    /** 修改员工（改名/改角色/重置密码） */ async updateEmployee(id, dto, operator) {
        return this.adminService.updateEmployee(id, dto, operator);
    }
    /** 删除员工（名下数据转移到操作者） */ async deleteEmployee(id, operator) {
        await this.adminService.deleteEmployee(id, operator);
        return {
            ok: true
        };
    }
    constructor(adminService){
        this.adminService = adminService;
    }
};
_ts_decorate([
    (0, _common.Get)('overview'),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", []),
    _ts_metadata("design:returntype", Promise)
], AdminController.prototype, "getOverview", null);
_ts_decorate([
    (0, _common.Get)('employees'),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", []),
    _ts_metadata("design:returntype", Promise)
], AdminController.prototype, "getEmployees", null);
_ts_decorate([
    (0, _common.Post)('employees'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof CreateEmployeeDto === "undefined" ? Object : CreateEmployeeDto
    ]),
    _ts_metadata("design:returntype", Promise)
], AdminController.prototype, "createEmployee", null);
_ts_decorate([
    (0, _common.Patch)('employees/:id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)()),
    _ts_param(2, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        typeof UpdateEmployeeDto === "undefined" ? Object : UpdateEmployeeDto,
        typeof Employee === "undefined" ? Object : Employee
    ]),
    _ts_metadata("design:returntype", Promise)
], AdminController.prototype, "updateEmployee", null);
_ts_decorate([
    (0, _common.Delete)('employees/:id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        typeof Employee === "undefined" ? Object : Employee
    ]),
    _ts_metadata("design:returntype", Promise)
], AdminController.prototype, "deleteEmployee", null);
AdminController = _ts_decorate([
    (0, _common.Controller)('api/admin'),
    (0, _common.UseGuards)(_employeeauthguard.EmployeeAuthGuard, _adminguard.AdminGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _adminservice.AdminService === "undefined" ? Object : _adminservice.AdminService
    ])
], AdminController);
