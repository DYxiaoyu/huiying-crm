"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SupplierPublicController", {
    enumerable: true,
    get: function() {
        return SupplierPublicController;
    }
});
const _common = require("@nestjs/common");
const _supplierpublicservice = require("./supplier-public.service");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let SupplierPublicController = class SupplierPublicController {
    async apply(dto) {
        return this.supplierPublicService.apply(dto);
    }
    /** 查询某密钥最近被驳回的记录（用于提交页回显理由） */ async rejected(key) {
        return this.supplierPublicService.rejected(key || '');
    }
    /** 校验密钥有效性 */ async verifyKey(body) {
        return this.supplierPublicService.verifyKey(body?.key || '');
    }
    constructor(supplierPublicService){
        this.supplierPublicService = supplierPublicService;
    }
};
_ts_decorate([
    (0, _common.Post)('apply'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PublicApplyDto === "undefined" ? Object : PublicApplyDto
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierPublicController.prototype, "apply", null);
_ts_decorate([
    (0, _common.Get)('rejected'),
    _ts_param(0, (0, _common.Query)('key')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierPublicController.prototype, "rejected", null);
_ts_decorate([
    (0, _common.Post)('verify-key'),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierPublicController.prototype, "verifyKey", null);
SupplierPublicController = _ts_decorate([
    (0, _common.Controller)('api/public/supplier'),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _supplierpublicservice.SupplierPublicService === "undefined" ? Object : _supplierpublicservice.SupplierPublicService
    ])
], SupplierPublicController);
