"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SuppliersService", {
    enumerable: true,
    get: function() {
        return SuppliersService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _schema = require("../../database/schema");
const _drizzleorm = require("drizzle-orm");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let SuppliersService = class SuppliersService {
    /**
   * 供应商商品对所有登录用户可见可搜（团队共享）
   */ async list(params) {
        const { page, pageSize: rawPageSize, keyword, category, status, sortBy, sortOrder } = params;
        const safePage = Math.max(1, page);
        const safePageSize = Math.min(50, Math.max(1, rawPageSize));
        const offset = (safePage - 1) * safePageSize;
        const conditions = [];
        if (keyword && keyword.trim()) {
            const pattern = `%${keyword.trim()}%`;
            conditions.push((0, _drizzleorm.or)((0, _drizzleorm.ilike)(_schema.supplierProducts.productName, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.supplierName, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.category, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.spec, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.contactName, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.contactPhone, pattern), (0, _drizzleorm.ilike)(_schema.supplierProducts.mainCategory, pattern)));
        }
        if (category && category.trim()) {
            conditions.push((0, _drizzleorm.eq)(_schema.supplierProducts.category, category.trim()));
        }
        if (status) {
            conditions.push((0, _drizzleorm.eq)(_schema.supplierProducts.status, status));
        }
        const whereClause = conditions.length > 0 ? (0, _drizzleorm.and)(...conditions) : undefined;
        const orderCol = sortBy === 'createdAt' ? _schema.supplierProducts.createdAt : sortBy === 'productName' ? _schema.supplierProducts.productName : sortBy === 'price' ? _schema.supplierProducts.price : _schema.supplierProducts.updatedAt;
        const orderFn = sortOrder === 'asc' ? _drizzleorm.asc : _drizzleorm.desc;
        const [countResult, rows, supplierRows] = await Promise.all([
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.supplierProducts).where(whereClause),
            this.db.select().from(_schema.supplierProducts).where(whereClause).orderBy(orderFn(orderCol)).limit(safePageSize).offset(offset),
            this.db.select({
                supplierName: _schema.supplierProducts.supplierName
            }).from(_schema.supplierProducts)
        ]);
        const total = Number(countResult[0]?.count ?? 0);
        const supplierSet = new Set();
        for (const r of supplierRows){
            if (r.supplierName) supplierSet.add(r.supplierName);
        }
        return {
            items: rows.map((row)=>this.toSupplierProduct(row)),
            total,
            page: safePage,
            pageSize: safePageSize,
            supplierCount: supplierSet.size
        };
    }
    async categories() {
        const rows = await this.db.select({
            category: _schema.supplierProducts.category
        }).from(_schema.supplierProducts);
        const set = new Set();
        for (const r of rows){
            if (r.category && r.category.trim()) set.add(r.category.trim());
        }
        return Array.from(set).sort((a, b)=>a.localeCompare(b, 'zh-CN'));
    }
    async create(dto, employeeId) {
        if (!dto.productName || !dto.productName.trim()) {
            throw new _common.BadRequestException('商品名称不能为空');
        }
        if (!dto.supplierName || !dto.supplierName.trim()) {
            throw new _common.BadRequestException('供应商名称不能为空');
        }
        const inserted = await this.db.insert(_schema.supplierProducts).values({
            productName: dto.productName.trim(),
            supplierName: dto.supplierName.trim(),
            category: dto.category?.trim() || null,
            price: dto.price?.trim() || null,
            unit: dto.unit?.trim() || null,
            spec: dto.spec?.trim() || null,
            imageUrl: dto.imageUrl || null,
            remark: dto.remark?.trim() || null,
            contactName: dto.contactName?.trim() || null,
            contactPhone: dto.contactPhone?.trim() || null,
            wechat: dto.wechat?.trim() || null,
            address: dto.address?.trim() || null,
            mainCategory: dto.mainCategory?.trim() || null,
            productUrl: dto.productUrl?.trim() || null,
            images: dto.images ? JSON.stringify(dto.images) : null,
            files: dto.files ? JSON.stringify(dto.files) : null,
            status: 'approved',
            employeeId
        }).returning();
        this.logger.log(`创建供应商商品成功: ${inserted[0].id}`);
        return this.toSupplierProduct(inserted[0]);
    }
    async update(id, dto) {
        const existing = await this.db.select().from(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('商品不存在');
        }
        const patch = {};
        if (dto.productName !== undefined) patch.productName = dto.productName.trim();
        if (dto.supplierName !== undefined) patch.supplierName = dto.supplierName.trim();
        if (dto.category !== undefined) patch.category = dto.category.trim() || null;
        if (dto.price !== undefined) patch.price = dto.price.trim() || null;
        if (dto.unit !== undefined) patch.unit = dto.unit.trim() || null;
        if (dto.spec !== undefined) patch.spec = dto.spec.trim() || null;
        if (dto.imageUrl !== undefined) patch.imageUrl = dto.imageUrl || null;
        if (dto.remark !== undefined) patch.remark = dto.remark.trim() || null;
        if (dto.contactName !== undefined) patch.contactName = dto.contactName.trim() || null;
        if (dto.contactPhone !== undefined) patch.contactPhone = dto.contactPhone.trim() || null;
        if (dto.wechat !== undefined) patch.wechat = dto.wechat.trim() || null;
        if (dto.address !== undefined) patch.address = dto.address.trim() || null;
        if (dto.mainCategory !== undefined) patch.mainCategory = dto.mainCategory.trim() || null;
        if (dto.productUrl !== undefined) patch.productUrl = dto.productUrl.trim() || null;
        if (dto.images !== undefined) patch.images = dto.images ? JSON.stringify(dto.images) : null;
        if (dto.files !== undefined) patch.files = dto.files ? JSON.stringify(dto.files) : null;
        if (Object.keys(patch).length === 0) {
            throw new _common.BadRequestException('未提供可更新字段');
        }
        patch.updatedAt = new Date();
        const updated = await this.db.update(_schema.supplierProducts).set(patch).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).returning();
        this.logger.log(`更新供应商商品成功: ${id}`);
        return this.toSupplierProduct(updated[0]);
    }
    async remove(id) {
        const existing = await this.db.select().from(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('商品不存在');
        }
        await this.db.delete(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id));
        this.logger.log(`删除供应商商品成功: ${id}`);
    }
    /** 审核通过 */ async approve(id) {
        const existing = await this.db.select().from(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('商品不存在');
        }
        const updated = await this.db.update(_schema.supplierProducts).set({
            status: 'approved',
            rejectReason: null,
            updatedAt: new Date()
        }).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).returning();
        this.logger.log(`审核通过供应商商品: ${id}`);
        return this.toSupplierProduct(updated[0]);
    }
    /** 审核驳回 */ async reject(id, reason) {
        const existing = await this.db.select().from(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).limit(1);
        if (existing.length === 0) {
            throw new _common.NotFoundException('商品不存在');
        }
        if (!reason || !reason.trim()) {
            throw new _common.BadRequestException('请填写驳回理由');
        }
        const updated = await this.db.update(_schema.supplierProducts).set({
            status: 'rejected',
            rejectReason: reason.trim(),
            updatedAt: new Date()
        }).where((0, _drizzleorm.eq)(_schema.supplierProducts.id, id)).returning();
        this.logger.log(`审核驳回供应商商品: ${id}`);
        return this.toSupplierProduct(updated[0]);
    }
    async importItems(items, employeeId) {
        if (!Array.isArray(items) || items.length === 0) {
            throw new _common.BadRequestException('没有可导入的数据');
        }
        const errors = [];
        let imported = 0;
        const validRows = [];
        items.forEach((item, index)=>{
            const productName = item.productName?.trim();
            const supplierName = item.supplierName?.trim();
            if (!productName || !supplierName) {
                errors.push(`第 ${index + 1} 行缺少商品名称或供应商名称`);
                return;
            }
            validRows.push({
                productName,
                supplierName,
                category: item.category?.trim() || null,
                price: item.price?.trim() || null,
                unit: item.unit?.trim() || null,
                spec: item.spec?.trim() || null,
                remark: item.remark?.trim() || null,
                status: 'approved',
                employeeId
            });
        });
        if (validRows.length > 0) {
            // 分批插入（每批 200 条），避免单条超长 SQL
            for(let i = 0; i < validRows.length; i += 200){
                const batch = validRows.slice(i, i + 200);
                await this.db.insert(_schema.supplierProducts).values(batch);
            }
            imported = validRows.length;
        }
        this.logger.log(`导入供应商商品成功: ${imported} 条, 跳过 ${items.length - imported} 条`);
        return {
            imported,
            skipped: items.length - imported,
            errors
        };
    }
    toSupplierProduct(row) {
        let files = null;
        if (row.files) {
            try {
                const parsed = JSON.parse(row.files);
                if (Array.isArray(parsed)) files = parsed;
            } catch  {
                files = null;
            }
        }
        let images = null;
        if (row.images) {
            try {
                const parsed = JSON.parse(row.images);
                if (Array.isArray(parsed)) images = parsed;
            } catch  {
                images = null;
            }
        }
        return {
            id: row.id,
            productName: row.productName,
            supplierName: row.supplierName,
            category: row.category,
            price: row.price,
            unit: row.unit,
            spec: row.spec,
            imageUrl: row.imageUrl,
            images,
            remark: row.remark,
            contactName: row.contactName,
            contactPhone: row.contactPhone,
            wechat: row.wechat,
            address: row.address,
            mainCategory: row.mainCategory,
            productUrl: row.productUrl,
            files,
            status: row.status ?? 'pending',
            rejectReason: row.rejectReason,
            submitKey: row.submitKey,
            employeeId: row.employeeId ?? '',
            createdAt: row.createdAt.toISOString(),
            updatedAt: row.updatedAt.toISOString()
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(SuppliersService.name);
    }
};
SuppliersService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], SuppliersService);
