"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DRIZZLE_DATABASE () {
        return DRIZZLE_DATABASE;
    },
    get DatabaseModule () {
        return DatabaseModule;
    }
});
const _common = require("@nestjs/common");
const _postgresjs = require("drizzle-orm/postgres-js");
const _postgres = /*#__PURE__*/ _interop_require_default(require("postgres"));
const _schema = /*#__PURE__*/ _interop_require_wildcard(require("./schema"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) return obj;
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") return {
        default: obj
    };
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) return cache.get(obj);
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) Object.defineProperty(newObj, key, desc);
            else newObj[key] = obj[key];
        }
    }
    newObj.default = obj;
    if (cache) cache.set(obj, newObj);
    return newObj;
}
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
const DRIZZLE_DATABASE = Symbol('DRIZZLE_DATABASE');
/**
 * 启动时自动建表（幂等），确保 PostgreSQL 中表结构存在
 */ async function ensureSchema(client) {
    await client.unsafe(`
    CREATE TABLE IF NOT EXISTS employees (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      name varchar(100) NOT NULL,
      username varchar(50) NOT NULL UNIQUE,
      password_hash varchar(255) NOT NULL,
      role varchar(20) NOT NULL DEFAULT 'employee',
      _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _created_by uuid,
      _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _updated_by uuid
    );

    -- 员工角色字段（老表升级，幂等）
    ALTER TABLE employees ADD COLUMN IF NOT EXISTS role varchar(20) NOT NULL DEFAULT 'employee';
    -- admin 账号提升为管理员（老板专享后台）
    UPDATE employees SET role = 'admin' WHERE username = 'admin' AND role <> 'admin';

    CREATE TABLE IF NOT EXISTS customers (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      name varchar(100) NOT NULL,
      phone varchar(50),
      company varchar(255),
      source varchar(100),
      stage varchar(50) NOT NULL DEFAULT 'new',
      remark text,
      owner uuid,
      employee_id uuid,
      _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _created_by uuid,
      _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _updated_by uuid
    );

    CREATE TABLE IF NOT EXISTS follow_ups (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
      content text NOT NULL,
      result varchar(255),
      follow_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      owner uuid,
      employee_id uuid,
      _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _created_by uuid,
      _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _updated_by uuid
    );

    CREATE INDEX IF NOT EXISTS idx_follow_ups_customer ON follow_ups(customer_id);
    CREATE INDEX IF NOT EXISTS idx_follow_ups_employee ON follow_ups(employee_id);
    CREATE INDEX IF NOT EXISTS idx_customers_stage ON customers(stage);
    CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name);
    CREATE INDEX IF NOT EXISTS idx_customers_employee ON customers(employee_id);

    CREATE TABLE IF NOT EXISTS supplier_products (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      product_name varchar(200) NOT NULL,
      supplier_name varchar(200) NOT NULL,
      category varchar(100),
      price varchar(50),
      unit varchar(20),
      spec varchar(200),
      image_url text,
      remark text,
      employee_id uuid,
      _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _created_by uuid,
      _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _updated_by uuid
    );
    CREATE INDEX IF NOT EXISTS idx_supplier_products_name ON supplier_products(product_name);
    CREATE INDEX IF NOT EXISTS idx_supplier_products_supplier ON supplier_products(supplier_name);
    CREATE INDEX IF NOT EXISTS idx_supplier_products_category ON supplier_products(category);
    CREATE INDEX IF NOT EXISTS idx_supplier_products_employee ON supplier_products(employee_id);

    -- 供应商公开提交扩展字段（老表升级用，幂等）
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS contact_name varchar(100);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS contact_phone varchar(50);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS wechat varchar(100);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS address varchar(255);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS main_category varchar(100);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS product_url text;
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS files text;
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS status varchar(20) NOT NULL DEFAULT 'pending';
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS reject_reason text;
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS submit_key varchar(100);
    ALTER TABLE supplier_products ADD COLUMN IF NOT EXISTS images text;
    ALTER TABLE supplier_products ALTER COLUMN product_name DROP NOT NULL;
    CREATE INDEX IF NOT EXISTS idx_supplier_products_status ON supplier_products(status);

    CREATE TABLE IF NOT EXISTS supplier_keys (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      "key" varchar(100) NOT NULL UNIQUE,
      label varchar(200) NOT NULL,
      enabled boolean NOT NULL DEFAULT true,
      _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _created_by uuid,
      _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
      _updated_by uuid
    );

    -- 老数据兼容：既有商品默认已通过
    UPDATE supplier_products SET status = 'approved' WHERE status = 'pending' AND submit_key IS NULL;

    -- 收藏字段（老表升级用，幂等）
    ALTER TABLE customers ADD COLUMN IF NOT EXISTS is_favorite boolean NOT NULL DEFAULT false;
  `);
}
let DatabaseModule = class DatabaseModule {
};
DatabaseModule = _ts_decorate([
    (0, _common.Global)(),
    (0, _common.Module)({
        providers: [
            {
                provide: DRIZZLE_DATABASE,
                useFactory: async ()=>{
                    const connectionString = process.env.DATABASE_URL;
                    if (!connectionString) {
                        throw new Error('DATABASE_URL 环境变量未设置，无法连接 PostgreSQL');
                    }
                    // Render 等托管数据库强制 SSL，这里统一开启
                    const client = (0, _postgres.default)(connectionString, {
                        max: 5,
                        ssl: 'require'
                    });
                    await ensureSchema(client);
                    return (0, _postgresjs.drizzle)(client, {
                        schema: _schema
                    });
                }
            }
        ],
        exports: [
            DRIZZLE_DATABASE
        ]
    })
], DatabaseModule);
