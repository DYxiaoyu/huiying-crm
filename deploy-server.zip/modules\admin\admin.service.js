"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AdminService", {
    enumerable: true,
    get: function() {
        return AdminService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _drizzleorm = require("drizzle-orm");
const _bcryptjs = require("bcryptjs");
const _schema = require("../../database/schema");
const _apiinterface = require("../../../shared/api.interface");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,20}$/;
let AdminService = class AdminService {
    /** 老板后台总览 + 员工列表（一次返回） */ async getOverview() {
        const [customerRow, supplierRow, employeeRow, keyRow, followRow] = await Promise.all([
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.customers),
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.supplierProducts),
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.employees),
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.supplierKeys),
            this.db.select({
                count: (0, _drizzleorm.count)()
            }).from(_schema.followUps)
        ]);
        const stageRows = await this.db.select({
            stage: _schema.customers.stage,
            c: (0, _drizzleorm.count)()
        }).from(_schema.customers).groupBy(_schema.customers.stage);
        const stageMap = {};
        for (const r of stageRows){
            stageMap[r.stage] = Number(r.c);
        }
        const stageDistribution = _apiinterface.STAGE_ORDER.map((stage)=>({
                stage,
                name: _apiinterface.STAGE_NAMES[stage],
                count: stageMap[stage] ?? 0
            }));
        const pendingRow = await this.db.select({
            count: (0, _drizzleorm.count)()
        }).from(_schema.supplierProducts).where((0, _drizzleorm.eq)(_schema.supplierProducts.status, 'pending'));
        const adminRow = await this.db.select({
            count: (0, _drizzleorm.count)()
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.role, 'admin'));
        const overview = {
            customerTotal: Number(customerRow[0]?.count ?? 0),
            customerByStage: stageDistribution,
            supplierTotal: Number(supplierRow[0]?.count ?? 0),
            supplierPending: Number(pendingRow[0]?.count ?? 0),
            employeeTotal: Number(employeeRow[0]?.count ?? 0),
            adminTotal: Number(adminRow[0]?.count ?? 0),
            supplierKeyTotal: Number(keyRow[0]?.count ?? 0),
            followUpTotal: Number(followRow[0]?.count ?? 0)
        };
        const employeesList = await this.getEmployeeList();
        return {
            overview,
            employees: employeesList
        };
    }
    /** 员工列表（含名下客户数/供应商数） */ async getEmployeeList() {
        const rows = await this.db.select({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            role: _schema.employees.role,
            createdAt: _schema.employees.createdAt
        }).from(_schema.employees).orderBy(_schema.employees.createdAt);
        const customerCounts = await this.db.select({
            employeeId: _schema.customers.employeeId,
            c: (0, _drizzleorm.count)()
        }).from(_schema.customers).groupBy(_schema.customers.employeeId);
        const supplierCounts = await this.db.select({
            employeeId: _schema.supplierProducts.employeeId,
            c: (0, _drizzleorm.count)()
        }).from(_schema.supplierProducts).groupBy(_schema.supplierProducts.employeeId);
        const cMap = new Map();
        for (const r of customerCounts){
            if (r.employeeId) cMap.set(r.employeeId, Number(r.c));
        }
        const sMap = new Map();
        for (const r of supplierCounts){
            if (r.employeeId) sMap.set(r.employeeId, Number(r.c));
        }
        return rows.map((row)=>({
                id: row.id,
                name: row.name,
                username: row.username,
                role: row.role === 'admin' ? 'admin' : 'employee',
                createdAt: row.createdAt.toISOString(),
                customerCount: cMap.get(row.id) ?? 0,
                supplierCount: sMap.get(row.id) ?? 0
            }));
    }
    /** 创建员工账号（老板操作） */ async createEmployee(dto) {
        const { name, username, password, role } = dto;
        if (!USERNAME_REGEX.test(username || '')) {
            throw new _common.BadRequestException('用户名需为3-20位字母、数字或下划线');
        }
        if (!password || password.length < 4) {
            throw new _common.BadRequestException('密码至少4位');
        }
        if (!name || name.trim().length === 0) {
            throw new _common.BadRequestException('姓名不能为空');
        }
        const existing = await this.db.select({
            id: _schema.employees.id
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.username, username));
        if (existing.length > 0) {
            throw new _common.ConflictException('用户名已存在');
        }
        const passwordHash = (0, _bcryptjs.hashSync)(password, 10);
        const targetRole = role === 'admin' ? 'admin' : 'employee';
        const inserted = await this.db.insert(_schema.employees).values({
            name: name.trim(),
            username,
            passwordHash,
            role: targetRole
        }).returning({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            role: _schema.employees.role,
            createdAt: _schema.employees.createdAt
        });
        this.logger.log(`老板创建员工账号: ${username} (${targetRole})`);
        return {
            id: inserted[0].id,
            name: inserted[0].name,
            username: inserted[0].username,
            role: inserted[0].role === 'admin' ? 'admin' : 'employee',
            createdAt: inserted[0].createdAt.toISOString(),
            customerCount: 0,
            supplierCount: 0
        };
    }
    /** 修改员工（改名/改角色/重置密码） */ async updateEmployee(id, dto, operator) {
        const target = await this.findEmployee(id);
        if (!target) {
            throw new _common.NotFoundException('员工不存在');
        }
        const patch = {};
        if (dto.name !== undefined) {
            if (!dto.name.trim()) throw new _common.BadRequestException('姓名不能为空');
            patch.name = dto.name.trim();
        }
        if (dto.role !== undefined) {
            const newRole = dto.role === 'admin' ? 'admin' : 'employee';
            // 不能把自己降级（避免把最后一个管理员降级导致系统无管理员）
            if (id === operator.id && newRole !== 'admin') {
                throw new _common.ForbiddenException('不能修改自己的管理员角色');
            }
            if (newRole !== 'admin' && target.role === 'admin') {
                const adminCount = await this.countAdmins();
                if (adminCount <= 1) {
                    throw new _common.ForbiddenException('系统至少需要保留一个管理员');
                }
            }
            patch.role = newRole;
        }
        if (dto.password !== undefined) {
            if (!dto.password || dto.password.length < 4) {
                throw new _common.BadRequestException('密码至少4位');
            }
            patch.passwordHash = (0, _bcryptjs.hashSync)(dto.password, 10);
        }
        if (Object.keys(patch).length === 0) {
            return this.toItem(target);
        }
        const updated = await this.db.update(_schema.employees).set(patch).where((0, _drizzleorm.eq)(_schema.employees.id, id)).returning({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            role: _schema.employees.role,
            createdAt: _schema.employees.createdAt
        });
        this.logger.log(`老板更新员工账号: ${target.username}`);
        return this.toItem({
            id: updated[0].id,
            name: updated[0].name,
            username: updated[0].username,
            role: updated[0].role,
            createdAt: updated[0].createdAt
        });
    }
    /** 删除员工：名下客户/跟进/供应商商品转移给操作者（数据不丢失），禁止删自己与最后的管理员 */ async deleteEmployee(id, operator) {
        if (id === operator.id) {
            throw new _common.ForbiddenException('不能删除自己的账号');
        }
        const target = await this.findEmployee(id);
        if (!target) {
            throw new _common.NotFoundException('员工不存在');
        }
        if (target.role === 'admin') {
            const adminCount = await this.countAdmins();
            if (adminCount <= 1) {
                throw new _common.ForbiddenException('系统至少需要保留一个管理员，请先将其他账号设为管理员');
            }
        }
        // 数据转移：客户/跟进/供应商商品归操作者（老板）名下，避免数据丢失
        await this.db.transaction(async (tx)=>{
            await tx.update(_schema.customers).set({
                employeeId: operator.id
            }).where((0, _drizzleorm.eq)(_schema.customers.employeeId, id));
            await tx.update(_schema.followUps).set({
                employeeId: operator.id
            }).where((0, _drizzleorm.eq)(_schema.followUps.employeeId, id));
            await tx.update(_schema.supplierProducts).set({
                employeeId: operator.id
            }).where((0, _drizzleorm.eq)(_schema.supplierProducts.employeeId, id));
            await tx.delete(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.id, id));
        });
        this.logger.log(`老板删除员工账号: ${target.username}（其名下数据已转移到 ${operator.username}）`);
    }
    async findEmployee(id) {
        const rows = await this.db.select({
            id: _schema.employees.id,
            name: _schema.employees.name,
            username: _schema.employees.username,
            role: _schema.employees.role,
            createdAt: _schema.employees.createdAt
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.id, id)).limit(1);
        return rows[0] ?? null;
    }
    async countAdmins() {
        const rows = await this.db.select({
            count: (0, _drizzleorm.count)()
        }).from(_schema.employees).where((0, _drizzleorm.eq)(_schema.employees.role, 'admin'));
        return Number(rows[0]?.count ?? 0);
    }
    toItem(row) {
        return {
            id: row.id,
            name: row.name,
            username: row.username,
            role: row.role === 'admin' ? 'admin' : 'employee',
            createdAt: row.createdAt.toISOString(),
            customerCount: 0,
            supplierCount: 0
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(AdminService.name);
    }
};
AdminService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], AdminService);
