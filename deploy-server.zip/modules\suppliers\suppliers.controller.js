"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SuppliersController", {
    enumerable: true,
    get: function() {
        return SuppliersController;
    }
});
const _common = require("@nestjs/common");
const _suppliersservice = require("./suppliers.service");
const _employeeauthguard = require("../auth/employee-auth.guard");
const _currentemployeedecorator = require("../auth/current-employee.decorator");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let SuppliersController = class SuppliersController {
    async list(page, pageSize, keyword, category, status, sortBy, sortOrder) {
        const pageNum = page ? parseInt(page, 10) : 1;
        const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 12;
        const safeSortBy = sortBy === 'createdAt' || sortBy === 'productName' || sortBy === 'price' ? sortBy : 'updatedAt';
        const safeSortOrder = sortOrder === 'asc' ? 'asc' : 'desc';
        const safeStatus = status === 'pending' || status === 'approved' || status === 'rejected' ? status : undefined;
        return this.suppliersService.list({
            page: pageNum,
            pageSize: pageSizeNum,
            keyword,
            category,
            status: safeStatus,
            sortBy: safeSortBy,
            sortOrder: safeSortOrder
        });
    }
    async categories() {
        return this.suppliersService.categories();
    }
    async importItems(employee, body) {
        return this.suppliersService.importItems(body?.items ?? [], employee.id);
    }
    async create(employee, dto) {
        return this.suppliersService.create(dto, employee.id);
    }
    async update(id, dto) {
        return this.suppliersService.update(id, dto);
    }
    async approve(id) {
        return this.suppliersService.approve(id);
    }
    async reject(id, body) {
        if (!body?.reason || !body.reason.trim()) {
            throw new _common.BadRequestException('请填写驳回理由');
        }
        return this.suppliersService.reject(id, body.reason);
    }
    async remove(id) {
        return this.suppliersService.remove(id);
    }
    constructor(suppliersService){
        this.suppliersService = suppliersService;
    }
};
_ts_decorate([
    (0, _common.Get)(),
    _ts_param(0, (0, _common.Query)('page')),
    _ts_param(1, (0, _common.Query)('pageSize')),
    _ts_param(2, (0, _common.Query)('keyword')),
    _ts_param(3, (0, _common.Query)('category')),
    _ts_param(4, (0, _common.Query)('status')),
    _ts_param(5, (0, _common.Query)('sortBy')),
    _ts_param(6, (0, _common.Query)('sortOrder')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        String,
        String,
        String,
        String,
        String,
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "list", null);
_ts_decorate([
    (0, _common.Get)('categories'),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", []),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "categories", null);
_ts_decorate([
    (0, _common.Post)('import'),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "importItems", null);
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _currentemployeedecorator.CurrentEmployee)()),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        Object,
        typeof CreateSupplierProductDto === "undefined" ? Object : CreateSupplierProductDto
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "create", null);
_ts_decorate([
    (0, _common.Patch)(':id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        typeof UpdateSupplierProductDto === "undefined" ? Object : UpdateSupplierProductDto
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "update", null);
_ts_decorate([
    (0, _common.Post)(':id/approve'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "approve", null);
_ts_decorate([
    (0, _common.Post)(':id/reject'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "reject", null);
_ts_decorate([
    (0, _common.Delete)(':id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SuppliersController.prototype, "remove", null);
SuppliersController = _ts_decorate([
    (0, _common.Controller)('api/suppliers'),
    (0, _common.UseGuards)(_employeeauthguard.EmployeeAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _suppliersservice.SuppliersService === "undefined" ? Object : _suppliersservice.SuppliersService
    ])
], SuppliersController);
