"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CurrentEmployee", {
    enumerable: true,
    get: function() {
        return CurrentEmployee;
    }
});
const _common = require("@nestjs/common");
const CurrentEmployee = (0, _common.createParamDecorator)((_data, ctx)=>{
    const request = ctx.switchToHttp().getRequest();
    return request.employee;
});
