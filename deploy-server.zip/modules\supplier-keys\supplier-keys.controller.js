"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SupplierKeysController", {
    enumerable: true,
    get: function() {
        return SupplierKeysController;
    }
});
const _common = require("@nestjs/common");
const _supplierkeysservice = require("./supplier-keys.service");
const _employeeauthguard = require("../auth/employee-auth.guard");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let SupplierKeysController = class SupplierKeysController {
    async list() {
        return this.supplierKeysService.list();
    }
    async create(dto) {
        return this.supplierKeysService.create(dto);
    }
    async update(id, body) {
        return this.supplierKeysService.update(id, body);
    }
    async remove(id) {
        return this.supplierKeysService.remove(id);
    }
    constructor(supplierKeysService){
        this.supplierKeysService = supplierKeysService;
    }
};
_ts_decorate([
    (0, _common.Get)(),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", []),
    _ts_metadata("design:returntype", Promise)
], SupplierKeysController.prototype, "list", null);
_ts_decorate([
    (0, _common.Post)(),
    _ts_param(0, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof CreateSupplierKeyDto === "undefined" ? Object : CreateSupplierKeyDto
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierKeysController.prototype, "create", null);
_ts_decorate([
    (0, _common.Patch)(':id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_param(1, (0, _common.Body)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String,
        Object
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierKeysController.prototype, "update", null);
_ts_decorate([
    (0, _common.Delete)(':id'),
    _ts_param(0, (0, _common.Param)('id')),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        String
    ]),
    _ts_metadata("design:returntype", Promise)
], SupplierKeysController.prototype, "remove", null);
SupplierKeysController = _ts_decorate([
    (0, _common.Controller)('api/supplier-keys'),
    (0, _common.UseGuards)(_employeeauthguard.EmployeeAuthGuard),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof _supplierkeysservice.SupplierKeysService === "undefined" ? Object : _supplierkeysservice.SupplierKeysService
    ])
], SupplierKeysController);
