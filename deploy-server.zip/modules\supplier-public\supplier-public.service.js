"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SupplierPublicService", {
    enumerable: true,
    get: function() {
        return SupplierPublicService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _schema = require("../../database/schema");
const _drizzleorm = require("drizzle-orm");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
const IMAGE_MIME = new Set([
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif'
]);
const DOC_MIME = new Set([
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/csv',
    'application/zip',
    'application/x-zip-compressed',
    'application/x-rar-compressed',
    'application/vnd.rar',
    'application/x-7z-compressed'
]);
const MAX_IMAGE_DATA = 4 * 1024 * 1024; // base64 字符串长度 ≈ 3MB 文件
const MAX_FILE_DATA = 70 * 1024 * 1024; // base64 ≈ 50MB 文件（Render 512MB 内存安全值；搬自有服务器后调大）
const MAX_FILES = 20;
let SupplierPublicService = class SupplierPublicService {
    async apply(dto) {
        const keyValue = dto.key?.trim();
        if (!keyValue) {
            throw new _common.BadRequestException('请填写供应商密钥');
        }
        const keyRows = await this.db.select().from(_schema.supplierKeys).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.supplierKeys.key, keyValue), (0, _drizzleorm.eq)(_schema.supplierKeys.enabled, true))).limit(1);
        if (keyRows.length === 0) {
            throw new _common.BadRequestException('供应商密钥无效或已停用，请联系合作方获取');
        }
        const supplierName = dto.supplierName?.trim();
        const contactName = dto.contactName?.trim();
        const contactPhone = dto.contactPhone?.trim();
        if (!supplierName) throw new _common.BadRequestException('请填写供应商名称');
        if (!contactName) throw new _common.BadRequestException('请填写联系人姓名');
        if (!contactPhone) throw new _common.BadRequestException('请填写联系电话');
        // 图片校验：多图数组（前端已压缩）
        const IMG_LIMIT = 500;
        const IMG_PER_IMG = 180 * 1024; // 压缩后单张 base64 上限 ~130KB
        let imageList = [];
        if (Array.isArray(dto.images) && dto.images.length > 0) {
            if (dto.images.length > IMG_LIMIT) {
                throw new _common.BadRequestException(`最多上传 ${IMG_LIMIT} 张图片`);
            }
            for (const img of dto.images){
                const s = (img || '').trim();
                if (!s) continue;
                if (s.length > IMG_PER_IMG) {
                    throw new _common.BadRequestException('单张图片过大，请压缩后再上传');
                }
                const mimeMatch = s.match(/^data:([^;]+);base64,/);
                if (!mimeMatch || !IMAGE_MIME.has(mimeMatch[1])) {
                    throw new _common.BadRequestException('仅支持 jpg / png / webp / gif 图片');
                }
                imageList.push(s);
            }
        }
        // 兼容旧版单图
        if (dto.imageData && dto.imageData.trim() && imageList.length === 0) {
            const s = dto.imageData.trim();
            if (s.length <= MAX_IMAGE_DATA) {
                const mimeMatch = s.match(/^data:([^;]+);base64,/);
                if (mimeMatch && IMAGE_MIME.has(mimeMatch[1])) imageList.push(s);
            }
        }
        const imageUrl = imageList[0] || null;
        const imagesJson = imageList.length > 0 ? JSON.stringify(imageList) : null;
        // 文件校验
        let filesJson = null;
        if (Array.isArray(dto.files) && dto.files.length > 0) {
            if (dto.files.length > MAX_FILES) {
                throw new _common.BadRequestException(`最多上传 ${MAX_FILES} 个文件`);
            }
            const files = [];
            for (const f of dto.files){
                const name = f.name?.trim();
                const mime = f.mime?.trim();
                const data = f.data?.trim();
                if (!name || !mime || !data) {
                    throw new _common.BadRequestException('文件信息不完整');
                }
                if (!DOC_MIME.has(mime)) {
                    throw new _common.BadRequestException(`文件「${name}」格式不支持，仅支持 PDF / Excel / Word / CSV`);
                }
                if (data.length > MAX_FILE_DATA) {
                    throw new _common.BadRequestException(`文件「${name}」过大，请压缩到 50MB 以内`);
                }
                // 防止危险文件名
                const safeName = name.replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
                files.push({
                    name: safeName,
                    mime,
                    size: f.size || data.length,
                    data
                });
            }
            filesJson = JSON.stringify(files);
        }
        // 商品列表：兼容旧版单商品字段
        let products;
        if (Array.isArray(dto.products) && dto.products.length > 0) {
            products = dto.products.map((p)=>({
                    productName: p.productName?.trim() || undefined,
                    price: p.price?.trim() || undefined,
                    unit: p.unit?.trim() || undefined,
                    spec: p.spec?.trim() || undefined,
                    productUrl: p.productUrl?.trim() || undefined,
                    remark: p.remark?.trim() || undefined
                }));
        } else {
            products = [
                {
                    productName: dto.productName?.trim() || undefined,
                    price: dto.price?.trim() || undefined,
                    unit: dto.unit?.trim() || undefined,
                    spec: dto.spec?.trim() || undefined,
                    productUrl: dto.productUrl?.trim() || undefined,
                    remark: dto.remark?.trim() || undefined
                }
            ];
        }
        if (products.length === 0) products = [
            {}
        ];
        // 防止商品过多
        if (products.length > 200) {
            throw new _common.BadRequestException('一次最多提交 200 个商品');
        }
        const baseRow = {
            supplierName,
            category: dto.mainCategory?.trim() || null,
            contactName,
            contactPhone,
            wechat: dto.wechat?.trim() || null,
            address: dto.address?.trim() || null,
            mainCategory: dto.mainCategory?.trim() || null,
            files: filesJson,
            images: imagesJson,
            status: 'pending',
            submitKey: keyValue,
            employeeId: null
        };
        let firstId = null;
        for (const p of products){
            const inserted = await this.db.insert(_schema.supplierProducts).values({
                ...baseRow,
                productName: p.productName || null,
                price: p.price || null,
                unit: p.unit || null,
                spec: p.spec || null,
                productUrl: p.productUrl || null,
                remark: p.remark || null,
                imageUrl
            }).returning();
            if (!firstId) firstId = inserted[0].id;
        }
        this.logger.log(`供应商公开提交成功: ${firstId} (${supplierName} / ${products.length} 个商品)`);
        return {
            ok: true,
            appliedId: firstId ?? undefined
        };
    }
    /** 查询某密钥最近被驳回的记录（最多 3 条） */ async rejected(keyValue) {
        if (!keyValue.trim()) return [];
        const rows = await this.db.select({
            productName: _schema.supplierProducts.productName,
            rejectReason: _schema.supplierProducts.rejectReason,
            updatedAt: _schema.supplierProducts.updatedAt
        }).from(_schema.supplierProducts).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.supplierProducts.submitKey, keyValue.trim()), (0, _drizzleorm.eq)(_schema.supplierProducts.status, 'rejected'))).orderBy(_schema.supplierProducts.updatedAt).limit(3);
        return rows.filter((r)=>r.rejectReason).map((r)=>({
                productName: r.productName,
                rejectReason: r.rejectReason ?? '',
                updatedAt: r.updatedAt.toISOString()
            }));
    }
    /** 校验密钥有效性（用于提交页进入表单前） */ async verifyKey(keyValue) {
        const key = keyValue?.trim();
        if (!key) throw new _common.BadRequestException('请填写合作密钥');
        const rows = await this.db.select({
            label: _schema.supplierKeys.label
        }).from(_schema.supplierKeys).where((0, _drizzleorm.and)((0, _drizzleorm.eq)(_schema.supplierKeys.key, key), (0, _drizzleorm.eq)(_schema.supplierKeys.enabled, true))).limit(1);
        if (rows.length === 0) {
            throw new _common.BadRequestException('合作密钥无效或已停用，请联系对接人确认');
        }
        return {
            ok: true,
            label: rows[0].label
        };
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(SupplierPublicService.name);
    }
};
SupplierPublicService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], SupplierPublicService);
