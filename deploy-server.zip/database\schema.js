/* eslint-disable */ /** auto generated, do not edit */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get customTimestamptz () {
        return customTimestamptz;
    },
    get customers () {
        return customers;
    },
    get customersTable () {
        return customersTable;
    },
    get employees () {
        return employees;
    },
    get employeesTable () {
        return employeesTable;
    },
    get escapeLiteral () {
        return escapeLiteral;
    },
    get fileAttachment () {
        return fileAttachment;
    },
    get fileAttachmentArray () {
        return fileAttachmentArray;
    },
    get followUps () {
        return followUps;
    },
    get followUpsTable () {
        return followUpsTable;
    },
    get supplierKeys () {
        return supplierKeys;
    },
    get supplierKeysTable () {
        return supplierKeysTable;
    },
    get supplierProducts () {
        return supplierProducts;
    },
    get supplierProductsTable () {
        return supplierProductsTable;
    },
    get userProfile () {
        return userProfile;
    },
    get userProfileArray () {
        return userProfileArray;
    }
});
const _drizzleorm = require("drizzle-orm");
const _pgcore = require("drizzle-orm/pg-core");
const customTimestamptz = (0, _pgcore.customType)({
    dataType (config) {
        const precision = typeof config?.precision !== 'undefined' ? ` (${config.precision})` : '';
        return `timestamptz${precision}`;
    },
    toDriver (value) {
        if (value == null) return value;
        if (typeof value === 'number') return new Date(value).toISOString();
        if (typeof value === 'string') return value;
        if (value instanceof Date) return value.toISOString();
        throw new Error('Invalid timestamp value');
    },
    fromDriver (value) {
        if (value instanceof Date) return value;
        return new Date(value);
    }
});
const userProfile = (0, _pgcore.customType)({
    dataType () {
        return 'user_profile';
    },
    toDriver (value) {
        return (0, _drizzleorm.sql)`ROW(${value})::user_profile`;
    },
    fromDriver (value) {
        const [userId] = value.slice(1, -1).split(',');
        return userId.trim();
    }
});
const fileAttachment = (0, _pgcore.customType)({
    dataType () {
        return 'file_attachment';
    },
    toDriver (value) {
        return (0, _drizzleorm.sql)`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
    },
    fromDriver (value) {
        const [bucketId, filePath] = value.slice(1, -1).split(',');
        return {
            bucket_id: bucketId.trim(),
            file_path: filePath.trim()
        };
    }
});
function escapeLiteral(str) {
    return "'" + str.replace(/'/g, "''") + "'";
}
const userProfileArray = (0, _pgcore.customType)({
    dataType () {
        return 'user_profile[]';
    },
    toDriver (value) {
        if (!value || value.length === 0) {
            return (0, _drizzleorm.sql)`'{}'::user_profile[]`;
        }
        const elements = value.map((id)=>`ROW(${escapeLiteral(id)})::user_profile`).join(',');
        return _drizzleorm.sql.raw(`ARRAY[${elements}]::user_profile[]`);
    },
    fromDriver (value) {
        if (!value || value === '{}') return [];
        const inner = value.slice(1, -1);
        const matches = inner.match(/\([^)]*\)/g) || [];
        return matches.map((m)=>m.slice(1, -1).split(',')[0].trim());
    }
});
const fileAttachmentArray = (0, _pgcore.customType)({
    dataType () {
        return 'file_attachment[]';
    },
    toDriver (value) {
        if (!value || value.length === 0) {
            return (0, _drizzleorm.sql)`'{}'::file_attachment[]`;
        }
        const elements = value.map((f)=>`ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`).join(',');
        return _drizzleorm.sql.raw(`ARRAY[${elements}]::file_attachment[]`);
    },
    fromDriver (value) {
        if (!value || value === '{}') return [];
        const inner = value.slice(1, -1);
        const matches = inner.match(/\([^)]*\)/g) || [];
        return matches.map((m)=>{
            const [bucketId, filePath] = m.slice(1, -1).split(',');
            return {
                bucket_id: bucketId.trim(),
                file_path: filePath.trim()
            };
        });
    }
});
const employees = (0, _pgcore.pgTable)("employees", {
    id: (0, _pgcore.uuid)("id").primaryKey().defaultRandom(),
    name: (0, _pgcore.varchar)("name", {
        length: 100
    }).notNull(),
    username: (0, _pgcore.varchar)("username", {
        length: 50
    }).notNull().unique(),
    passwordHash: (0, _pgcore.varchar)("password_hash", {
        length: 255
    }).notNull(),
    role: (0, _pgcore.varchar)("role", {
        length: 20
    }).notNull().default('employee'),
    // System field: Creation time (auto-filled, do not modify)
    createdAt: customTimestamptz("_created_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Creator (auto-filled, do not modify)
    createdBy: (0, _pgcore.uuid)("_created_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    // System field: Update time (auto-filled, do not modify)
    updatedAt: customTimestamptz("_updated_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Updater (auto-filled, do not modify)
    updatedBy: (0, _pgcore.uuid)("_updated_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`)
}, (table)=>[
        (0, _pgcore.uniqueIndex)("employees_username_key").on(table.username)
    ]);
const followUps = (0, _pgcore.pgTable)("follow_ups", {
    id: (0, _pgcore.uuid)("id").primaryKey().defaultRandom(),
    customerId: (0, _pgcore.uuid)("customer_id").notNull(),
    content: (0, _pgcore.text)("content").notNull(),
    result: (0, _pgcore.varchar)("result", {
        length: 255
    }),
    followAt: customTimestamptz("follow_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    owner: (0, _pgcore.uuid)("owner").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    employeeId: (0, _pgcore.uuid)("employee_id"),
    // System field: Creation time (auto-filled, do not modify)
    createdAt: customTimestamptz("_created_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Creator (auto-filled, do not modify)
    createdBy: (0, _pgcore.uuid)("_created_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    // System field: Update time (auto-filled, do not modify)
    updatedAt: customTimestamptz("_updated_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Updater (auto-filled, do not modify)
    updatedBy: (0, _pgcore.uuid)("_updated_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`)
}, (table)=>[
        (0, _pgcore.index)("idx_follow_ups_customer").on(table.customerId),
        // Complex index: CREATE INDEX idx_follow_ups_owner ON follow_ups USING btree (((owner).user_id)),
        (0, _pgcore.index)("idx_follow_ups_employee").on(table.employeeId),
        (0, _pgcore.foreignKey)({
            columns: [
                table.customerId
            ],
            foreignColumns: [
                customers.id
            ],
            name: "follow_ups_customer_id_fkey"
        }).onDelete("cascade")
    ]);
const customers = (0, _pgcore.pgTable)("customers", {
    id: (0, _pgcore.uuid)("id").primaryKey().defaultRandom(),
    name: (0, _pgcore.varchar)("name", {
        length: 100
    }).notNull(),
    phone: (0, _pgcore.varchar)("phone", {
        length: 50
    }),
    company: (0, _pgcore.varchar)("company", {
        length: 255
    }),
    source: (0, _pgcore.varchar)("source", {
        length: 100
    }),
    stage: (0, _pgcore.varchar)("stage", {
        length: 50
    }).notNull().default('new'),
    remark: (0, _pgcore.text)("remark"),
    isFavorite: (0, _pgcore.boolean)("is_favorite").notNull().default(false),
    owner: (0, _pgcore.uuid)("owner").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    employeeId: (0, _pgcore.uuid)("employee_id"),
    // System field: Creation time (auto-filled, do not modify)
    createdAt: customTimestamptz("_created_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Creator (auto-filled, do not modify)
    createdBy: (0, _pgcore.uuid)("_created_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    // System field: Update time (auto-filled, do not modify)
    updatedAt: customTimestamptz("_updated_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Updater (auto-filled, do not modify)
    updatedBy: (0, _pgcore.uuid)("_updated_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`)
}, (table)=>[
        // Complex index: CREATE INDEX idx_customers_owner ON customers USING btree (((owner).user_id)),
        (0, _pgcore.index)("idx_customers_stage").on(table.stage),
        (0, _pgcore.index)("idx_customers_name").on(table.name),
        (0, _pgcore.index)("idx_customers_employee").on(table.employeeId)
    ]);
const supplierProducts = (0, _pgcore.pgTable)("supplier_products", {
    id: (0, _pgcore.uuid)("id").primaryKey().defaultRandom(),
    productName: (0, _pgcore.varchar)("product_name", {
        length: 200
    }),
    supplierName: (0, _pgcore.varchar)("supplier_name", {
        length: 200
    }).notNull(),
    category: (0, _pgcore.varchar)("category", {
        length: 100
    }),
    price: (0, _pgcore.varchar)("price", {
        length: 50
    }),
    unit: (0, _pgcore.varchar)("unit", {
        length: 20
    }),
    spec: (0, _pgcore.varchar)("spec", {
        length: 200
    }),
    imageUrl: (0, _pgcore.text)("image_url"),
    images: (0, _pgcore.text)("images"),
    remark: (0, _pgcore.text)("remark"),
    // 供应商联系信息
    contactName: (0, _pgcore.varchar)("contact_name", {
        length: 100
    }),
    contactPhone: (0, _pgcore.varchar)("contact_phone", {
        length: 50
    }),
    wechat: (0, _pgcore.varchar)("wechat", {
        length: 100
    }),
    address: (0, _pgcore.varchar)("address", {
        length: 255
    }),
    mainCategory: (0, _pgcore.varchar)("main_category", {
        length: 100
    }),
    productUrl: (0, _pgcore.text)("product_url"),
    files: (0, _pgcore.text)("files"),
    status: (0, _pgcore.varchar)("status", {
        length: 20
    }).notNull().default('pending'),
    rejectReason: (0, _pgcore.text)("reject_reason"),
    submitKey: (0, _pgcore.varchar)("submit_key", {
        length: 100
    }),
    employeeId: (0, _pgcore.uuid)("employee_id"),
    // System field: Creation time (auto-filled, do not modify)
    createdAt: customTimestamptz("_created_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Creator (auto-filled, do not modify)
    createdBy: (0, _pgcore.uuid)("_created_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    // System field: Update time (auto-filled, do not modify)
    updatedAt: customTimestamptz("_updated_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Updater (auto-filled, do not modify)
    updatedBy: (0, _pgcore.uuid)("_updated_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`)
}, (table)=>[
        (0, _pgcore.index)("idx_supplier_products_name").on(table.productName),
        (0, _pgcore.index)("idx_supplier_products_supplier").on(table.supplierName),
        (0, _pgcore.index)("idx_supplier_products_category").on(table.category),
        (0, _pgcore.index)("idx_supplier_products_employee").on(table.employeeId),
        (0, _pgcore.index)("idx_supplier_products_status").on(table.status)
    ]);
const supplierKeys = (0, _pgcore.pgTable)("supplier_keys", {
    id: (0, _pgcore.uuid)("id").primaryKey().defaultRandom(),
    key: (0, _pgcore.varchar)("key", {
        length: 100
    }).notNull().unique(),
    label: (0, _pgcore.varchar)("label", {
        length: 200
    }).notNull(),
    enabled: (0, _pgcore.boolean)("enabled").notNull().default(true),
    // System field: Creation time (auto-filled, do not modify)
    createdAt: customTimestamptz("_created_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Creator (auto-filled, do not modify)
    createdBy: (0, _pgcore.uuid)("_created_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
    // System field: Update time (auto-filled, do not modify)
    updatedAt: customTimestamptz("_updated_at", {
        precision: 3
    }).notNull().default((0, _drizzleorm.sql)`CURRENT_TIMESTAMP`),
    // System field: Updater (auto-filled, do not modify)
    updatedBy: (0, _pgcore.uuid)("_updated_by").default((0, _drizzleorm.sql)`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`)
}, (table)=>[
        (0, _pgcore.uniqueIndex)("supplier_keys_key_key").on(table.key)
    ]);
const customersTable = customers;
const employeesTable = employees;
const followUpsTable = followUps;
const supplierProductsTable = supplierProducts;
const supplierKeysTable = supplierKeys;
