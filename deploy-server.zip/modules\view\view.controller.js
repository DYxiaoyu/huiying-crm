"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ViewController", {
    enumerable: true,
    get: function() {
        return ViewController;
    }
});
const _common = require("@nestjs/common");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let ViewController = class ViewController {
    wechatVerify(res) {
        res.type('text/plain').send('ec59ae89a05ec1501e72cc5ac6cf82c382ec0fd6');
    }
    async render(req) {
        const platformData = req.__platform_data__ ?? {};
        return {
            __platform__: JSON.stringify(platformData)
        };
    }
};
_ts_decorate([
    (0, _common.Get)('668f8dba359e1fbc0ae9efc9e983eab6.txt'),
    _ts_param(0, (0, _common.Res)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof Response === "undefined" ? Object : Response
    ]),
    _ts_metadata("design:returntype", void 0)
], ViewController.prototype, "wechatVerify", null);
_ts_decorate([
    (0, _common.Get)([
        '/',
        '*'
    ]),
    (0, _common.Render)('index'),
    _ts_param(0, (0, _common.Req)()),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof Request === "undefined" ? Object : Request
    ]),
    _ts_metadata("design:returntype", Promise)
], ViewController.prototype, "render", null);
ViewController = _ts_decorate([
    (0, _common.Controller)()
], ViewController);
