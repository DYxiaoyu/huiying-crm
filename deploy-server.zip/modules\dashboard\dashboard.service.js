"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DashboardService", {
    enumerable: true,
    get: function() {
        return DashboardService;
    }
});
const _common = require("@nestjs/common");
const _databasemodule = require("../../database/database.module");
const _drizzleorm = require("drizzle-orm");
const _schema = require("../../database/schema");
const _apiinterface = require("../../../shared/api.interface");
function _ts_decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
        r = Reflect.decorate(decorators, target, key, desc);
    } else {
        for(var i = decorators.length - 1; i >= 0; i--){
            if (d = decorators[i]) {
                r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
            }
        }
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function _ts_metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") {
        return Reflect.metadata(metadataKey, metadataValue);
    }
}
function _ts_param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
let DashboardService = class DashboardService {
    async getStats(employee) {
        const employeeId = employee.id;
        const allCustomers = await this.db.select({
            id: _schema.customers.id,
            stage: _schema.customers.stage,
            createdAt: _schema.customers.createdAt
        }).from(_schema.customers).where((0, _drizzleorm.eq)(_schema.customers.employeeId, employeeId));
        const total = allCustomers.length;
        const stageCounts = {};
        for (const stage of _apiinterface.STAGE_ORDER){
            stageCounts[stage] = 0;
        }
        for (const c of allCustomers){
            if (stageCounts[c.stage] !== undefined) {
                stageCounts[c.stage] += 1;
            }
        }
        const overdue = await this.countOverdue(employeeId, allCustomers);
        const stats = {
            total,
            overdue,
            following: stageCounts.following,
            closed: stageCounts.closed,
            newCustomers: stageCounts.new,
            lost: stageCounts.lost
        };
        const stageDistribution = _apiinterface.STAGE_ORDER.map((stage)=>({
                stage,
                name: _apiinterface.STAGE_NAMES[stage],
                count: stageCounts[stage]
            }));
        const recentFollowUps = await this.getRecentFollowUps(employeeId);
        this.logger.log(`概览统计查询成功, 员工: ${employee.username}, 客户数: ${total}`);
        return {
            stats,
            stageDistribution,
            recentFollowUps
        };
    }
    async countOverdue(employeeId, allCustomers) {
        if (allCustomers.length === 0) {
            return 0;
        }
        const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const latestFollows = await this.db.select({
            customerId: _schema.followUps.customerId,
            maxFollowAt: (0, _drizzleorm.max)(_schema.followUps.followAt)
        }).from(_schema.followUps).where((0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId)).groupBy(_schema.followUps.customerId);
        const latestFollowMap = new Map();
        for (const row of latestFollows){
            if (row.maxFollowAt) {
                latestFollowMap.set(row.customerId, row.maxFollowAt);
            }
        }
        let overdueCount = 0;
        for (const c of allCustomers){
            const lastFollow = latestFollowMap.get(c.id);
            const reference = lastFollow ?? c.createdAt;
            if (reference.getTime() < sevenDaysAgo.getTime()) {
                overdueCount += 1;
            }
        }
        return overdueCount;
    }
    async getRecentFollowUps(employeeId) {
        const rows = await this.db.select({
            id: _schema.followUps.id,
            customerId: _schema.followUps.customerId,
            customerName: _schema.customers.name,
            content: _schema.followUps.content,
            result: _schema.followUps.result,
            followAt: _schema.followUps.followAt,
            employeeId: _schema.followUps.employeeId,
            createdAt: _schema.followUps.createdAt
        }).from(_schema.followUps).leftJoin(_schema.customers, (0, _drizzleorm.eq)(_schema.followUps.customerId, _schema.customers.id)).where((0, _drizzleorm.eq)(_schema.followUps.employeeId, employeeId)).orderBy((0, _drizzleorm.desc)(_schema.followUps.followAt)).limit(8);
        return rows.map((row)=>({
                id: row.id,
                customerId: row.customerId,
                customerName: row.customerName || '',
                content: row.content,
                result: row.result,
                followAt: row.followAt.toISOString(),
                employeeId: row.employeeId || employeeId,
                createdAt: row.createdAt.toISOString()
            }));
    }
    constructor(db){
        this.db = db;
        this.logger = new _common.Logger(DashboardService.name);
    }
};
DashboardService = _ts_decorate([
    (0, _common.Injectable)(),
    _ts_param(0, (0, _common.Inject)(_databasemodule.DRIZZLE_DATABASE)),
    _ts_metadata("design:type", Function),
    _ts_metadata("design:paramtypes", [
        typeof PostgresJsDatabase === "undefined" ? Object : PostgresJsDatabase
    ])
], DashboardService);
